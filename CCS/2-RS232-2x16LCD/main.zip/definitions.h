#ifndef DEFINITIONS_H     
#define DEFINITIONS_H   
                                                    
typedef unsigned int16  uint16_t;
typedef unsigned int8   uint8_t;
typedef unsigned char   uchar_t;
              
#endif //DEFINITIONS_H      
